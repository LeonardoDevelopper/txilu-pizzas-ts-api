import { Request } from "express"

export interface customRequest extends Request {
    URL_PHOTO : string

}