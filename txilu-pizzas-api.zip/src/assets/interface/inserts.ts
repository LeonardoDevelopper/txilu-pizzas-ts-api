export interface ResponseMessage {
  OK : boolean,
  message: string
}

export interface ResponseMessageError {
  OK : boolean,
  messageError: string
}