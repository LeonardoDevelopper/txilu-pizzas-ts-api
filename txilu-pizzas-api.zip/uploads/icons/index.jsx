import { StyleSheet, Text, View, Image , ProgressBarAndroid, TextInput, TouchableHighlight } from 'react-native';
import Svg, { Circle, Rect } from 'react-native-svg';

const Footer = ({photo, name, notify, deliveries, time, distance}) => {
    return (
        <View style ={styles.containerFooter}>
            <View>
                <View>
                    <Image style={styles.userPhoto} source={{uri : photo}} />
                    <Text>
                        {name}
                    </Text>
                </View>
                <View>
                    {/* <Image source={require('../svg/')} /> */}
                    <Text>
                        {notify}
                    </Text>
                </View>
            </View>
            <View style = {styles.containerInfo2}>
                <View style={styles.containerTomato}>
                    <Image style={styles.img} source={require('../../img/ico/icons8_delivery_scooter_64 1.png')} />
                    <Text style={styles.textWhite}>Entregas</Text>
                    <Text style={styles.textWhiteBig}>9</Text>
                </View>
                <View style={styles.containerTomato}>
                    <Image style={styles.img} source={require('../../img/ico/icons8_speed_64 1.png')} />
                    <Text style={styles.textWhite}>Tempo</Text>
                    <Text style={styles.textWhiteBig}>3h</Text>
                </View>
                <View style={styles.containerTomato}>
                    <Image style={styles.img}  source={require('../../../../assets/ico/icons8_ruler_64 1.png')} />
                    <Text style={styles.textWhite}>Distância</Text>
                    <Text style={styles.textWhiteBig}>15Km</Text>
            
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    containerFooter : {
        position: 'absolute',
        zIndex: 100,
        bottom: 30,
        width : 330,
        height : 200,
        borderRadius : 20,
        elevation: 5, // Para Android
        backgroundColor : 'white',
        flexDirection: 'column',

    },
containerInfo2 :   {
    backgroundColor : 'tomato',
    borderRadius : 20,
    height : 130,
    flexDirection: 'row',
    gap : 40,
    justifyContent : 'center',
    alignItems : 'center'
  },
  img :{
    width: 60,
    height: 60,
    resizeMode: 'cover',
  },
  containerTomato : {
    justifyContent : 'center',
    alignContent : 'center'
  },
  userPhoto : {
    width : 50,
    height : 50
  }
  , textWhite : {
    color : 'white'
  },
  textWhiteBig : {
    color : 'white' 
  }
})

export default Footer